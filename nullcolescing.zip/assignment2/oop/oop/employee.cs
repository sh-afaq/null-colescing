﻿
namespace oop
{
    internal class employee
    {
        //encapsulation implemented
        private int age;
        private string name;
        private float salary;
        //property impelmented
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public float Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        public void employee_details(int age,string name,double salary)
        {
            Console.WriteLine("employee details are:");
            Console.WriteLine("Age is "+ age+"  " 
                + "Name is "+ name+" " +
                "Salary is "+ salary);
        }
        //polymorphism implemented
        public virtual void contract()
        {
            Console.WriteLine("here you can show the remaining contract");
        }

    }
    //inheritence implemented
    class CTO:employee
    {
       public int age=45;
       public string name="sajad";
       public double salary = 70000.00;
        public override void contract()
        {
            Console.WriteLine(" His remaining contract is of 3.5 years");
        }



    }
}
