﻿

namespace oop
{
    //ABSTRACTION IMPLEMENTED
    internal abstract class player
    {
        public abstract void game();
        public abstract void country();
        public abstract void pay();


    }
    internal class ronaldo : player
    {
        public override void game()
        {
            Console.WriteLine("he plays football");
        }
        public override void country()
        {
            Console.WriteLine("he is from portugal");
        }
        public override void pay()
        {
            Console.WriteLine("his pay is 26.8 million GBP");
        }
    }
}
