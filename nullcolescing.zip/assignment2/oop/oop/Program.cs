﻿namespace oop
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            CTO obj = new CTO();
            obj.employee_details(obj.age,obj.name,obj.salary);
            obj.contract();
            Console.WriteLine(" Abstract class functions :  ");
            ronaldo player1 = new ronaldo();
            player1.game();
            player1.country();
            player1.pay();
        }
    }
}