﻿namespace nll_coalescing
{
    internal class Program
    {
        


        static void Main(string[] args)
        {
            coalescing obj= new coalescing();
          
            obj.showname("abid");
            //deifference of decimal & double
             Decimal d1,d2,d3;
            d1 = 2.375m;
            d2 = 1.625m;
            d3 = d1 + d2;
            Console.WriteLine(d3);
            double num1, num2, num3;
            num1 = 2.375D;
            num2 = 1.625D;
            num3 = num1 + num2;
            Console.WriteLine(num3);

        }
    }
}