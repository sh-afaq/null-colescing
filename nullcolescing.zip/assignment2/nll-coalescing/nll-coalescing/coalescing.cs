﻿

namespace nll_coalescing
{
    // ??
    internal class coalescing
    {
        private string name;
        public string Name
        {
            set
            {
                name = value ?? "ali";
            }
        }
        public void showname(string name)
        {
            Console.WriteLine(name);
        }
    }
}
